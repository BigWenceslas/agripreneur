<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;


class ArticlesTv extends Model
{
    
}
